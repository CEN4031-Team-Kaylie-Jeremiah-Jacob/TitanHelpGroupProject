﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TitanHelp
{
    /// <summary>
    /// Interaction logic for CreateTicket.xaml
    /// </summary>
    public partial class CreateTicket : Window
    {
        public CreateTicket()
        {
            InitializeComponent();
        }

        private void ticketNameTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (ticketNameTextBox.Text == "")
            {
                ticketNameTextBox.Text = "Enter the name of your ticket";
            }
        }

        private void ticketNameTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (ticketNameTextBox.Text == "Enter the name of your ticket")
            {
                ticketNameTextBox.Clear();
            }
        }

        private void ticketContentTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (ticketContentTextBox.Text == "")
            {
                ticketContentTextBox.Text = "Enter the description of your problem";
            }
        }

        private void ticketContentTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (ticketContentTextBox.Text == "Enter the description of your problem")
            {
                ticketContentTextBox.Clear();
            }
        }

        private void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void submitButton_Click(object sender, RoutedEventArgs e)
        {
            if (ticketContentTextBox.Text != "Enter the description of your problem")
            {
                problemErrorLabel.Visibility = Visibility.Hidden;
            }
            if (ticketNameTextBox.Text != "Enter the name of your ticket")
            {
                ticketNameErrorLabel.Visibility = Visibility.Hidden;
            }
            if (dateSelector.Text != "")
            {
                dateErrorLabel.Visibility = Visibility.Hidden;
            }
            if (ticketContentTextBox.Text == "Enter the description of your problem")
            {
                errorLabel.Visibility = Visibility.Visible;
                problemErrorLabel.Visibility = Visibility.Visible;
            }
            else if (ticketNameTextBox.Text == "Enter the name of your ticket")
            {
                errorLabel.Visibility = Visibility.Visible;
                ticketNameErrorLabel.Visibility = Visibility.Visible;
            }
            else if (dateSelector.Text == "")
            {
                errorLabel.Visibility = Visibility.Visible;
                dateErrorLabel.Visibility = Visibility.Visible;
            }
            else
            {
                errorLabel.Visibility = Visibility.Hidden;

                // This is where you add the logic to add the data to the database, etc.

                Close();
            }
        }
    }
}
